// ================================
// SERVER STARTUP (BUNNY SHELL COMPATIBLE)
// ================================

const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0'; // Required for Bunny Shell

app.listen(PORT, HOST, () => {
  console.log(`\n🚀 Payment Backend Server Started`);
  console.log(`📡 Host: ${HOST}`);
  console.log(`📡 Port: ${PORT}`);
  console.log(`🔗 Server URL: http://${HOST}:${PORT}`);
  console.log(`🔥 Firebase: ${firebaseEnabled ? "✅ Enabled" : "❌ Disabled"}`);
  console.log(`📧 Email: ${emailConfigOK ? "✅ Configured" : "❌ Not configured"}`);
  console.log(`💳 Midtrans: ${midtransConfigOK ? "✅ Configured" : "❌ Not configured"}`);
  console.log(`🌐 Environment: ${process.env.NODE_ENV || "development"}`);
  console.log(`☁️ Platform: Bunny Shell`);
  console.log(`\n📝 IMPORTANT: Payment records are created by frontend, backend only updates status`);
  console.log(`\n📋 Available endpoints:`);
  console.log(`   GET    /`);
  console.log(`   GET    /health`);
  console.log(`   POST   /send-otp`);
  console.log(`   POST   /reset-password`);
  console.log(`   POST   /generate-snap-token`);
  console.log(`   POST   /midtrans-webhook`);
  console.log(`   GET    /payment-finish`);
  console.log(`   GET    /payment-status/:orderId`);
  console.log(`   POST   /payment-status`);
  console.log(`\n✅ Server ready to accept connections on Bunny Shell\n`);
});